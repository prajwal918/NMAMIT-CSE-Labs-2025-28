OS Laboratory - Line-by-Line Study Guide: source files
======================================================

code/exp1.c ... code/exp10.c  the ten programs of your lab manual (indentation added,
                              line numbers identical to the manual)
code/largest.sh               the shell script of Experiment 1
code/*_better.c, exp1_fork.c, exp3_status.c, exp9_menu_sem.c, exp9_threads.c
                              the improved versions explained in the guide
code/fcfs_at.c, sjf_at.c, srtf.c, rr_at.c
                              the scheduling "twist" programs with arrival times

Compile and run a C program:
    gcc -Wall -Wextra exp1.c -o exp1 && ./exp1
Programs that use semaphores or threads need one more flag:
    gcc -Wall -Wextra exp9_threads.c -o exp9_threads -pthread

Rebuild the PDF (needs XeLaTeX and the fonts TeX Gyre Pagella, TeX Gyre Heros,
DejaVu Sans Mono):
    xelatex main.tex
    xelatex main.tex        (a second run builds the table of contents)

cheat.tex                     the one-page revision sheet (compile it the same way: xelatex cheat.tex)

code/variations/              tested exam-style variations of the programs (append instead of truncate,
                              count lines, number of children from the keyboard, extra signal,
                              Gantt chart, priority scheduling, time slices, several producers and
                              consumers); CHANGES.txt shows the exact lines that differ

Experiment 10 (Banker's algorithm):
code/exp10.c                  the program of the lab manual (your notebook program plus three small fixes)
code/exp10_record.c           your notebook program exactly as written (it loops for ever on some unsafe inputs)
code/exp10_diff.txt           the exact differences between the two
code/exp10_request.c          the resource-request algorithm ("can this request be granted?")
code/variations/drill_exp*.c  nine more practice changes, one for every experiment (DRILLS.txt shows the exact lines that differ)
code/mock/                    programs used in the two mock papers of Appendix F (copy.c, sigcount.c, mock_q1.c, smallest.sh)
