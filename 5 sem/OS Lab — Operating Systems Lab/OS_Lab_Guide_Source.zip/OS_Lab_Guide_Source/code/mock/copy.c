#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    char src[100], dst[100], buffer[100];
    int in, out;
    ssize_t n;
    printf("Enter source file: ");
    scanf("%99s", src);
    printf("Enter destination file: ");
    scanf("%99s", dst);
    in = open(src, O_RDONLY);
    if (in == -1)
    {
        perror(src);
        return 1;
    }
    out = open(dst, O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (out == -1)
    {
        perror(dst);
        close(in);
        return 1;
    }
    while ((n = read(in, buffer, sizeof(buffer))) > 0)
    {
        if (write(out, buffer, n) != n)
        {
            perror("write");
            break;
        }
    }
    if (n == -1)
        perror("read");
    close(in);
    close(out);
    printf("Copy finished\n");
    return 0;
}
