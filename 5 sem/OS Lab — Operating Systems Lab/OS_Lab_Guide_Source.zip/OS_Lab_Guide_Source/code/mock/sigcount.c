#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

int count = 0;

void handler(int sig)
{
    count++;
    printf("Ctrl+C pressed %d time(s)\n", count);
    if(count == 3)
    {
        printf("Third time: exiting\n");
        exit(0);
    }
}

int main()
{
    signal(SIGINT, handler);
    printf("PID = %d\n", getpid());
    while(1)
        pause();
    return 0;
}
