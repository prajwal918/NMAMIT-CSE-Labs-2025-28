#include <stdio.h>

struct Process { int pid, at, bt, ct, tat, wt, done; };

int main(void)
{
    int n, i, finished = 0, time = 0;
    double twt = 0, ttat = 0;
    printf("Enter number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0) return 1;
    struct Process p[n];
    for (i = 0; i < n; i++) {
        p[i].pid = i + 1;  p[i].done = 0;
        printf("Arrival time and burst time of P%d: ", i + 1);
        if (scanf("%d %d", &p[i].at, &p[i].bt) != 2) return 1;
    }
    while (finished < n) {
        int k = -1;                              /* index of the chosen process */
        for (i = 0; i < n; i++)
            if (!p[i].done && p[i].at <= time &&             /* has arrived     */
                (k == -1 || p[i].bt < p[k].bt ||             /* shorter burst   */
                 (p[i].bt == p[k].bt && p[i].at < p[k].at))) /* tie: earlier AT */
                k = i;
        if (k == -1) { time++; continue; }       /* nobody has arrived: CPU idle */
        time += p[k].bt;                         /* run it to completion         */
        p[k].ct  = time;
        p[k].tat = p[k].ct - p[k].at;
        p[k].wt  = p[k].tat - p[k].bt;
        p[k].done = 1;  finished++;
        twt += p[k].wt;  ttat += p[k].tat;
    }
    printf("\nPID AT BT CT TAT WT\n");
    for (i = 0; i < n; i++)
        printf("P%d %d %d %d %d %d\n", p[i].pid, p[i].at, p[i].bt,
               p[i].ct, p[i].tat, p[i].wt);
    printf("Average WT = %.2f   Average TAT = %.2f\n", twt / n, ttat / n);
    return 0;
}
