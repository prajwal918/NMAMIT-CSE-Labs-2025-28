#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

int main(void)
{
    char fname[256], buf[4096];
    printf("Enter filename: ");
    if (scanf("%255s", fname) != 1) return 1;
    int fd = open(fname, O_RDONLY);
    if (fd == -1) { perror(fname); return 1; }
    printf("file contents:\n");
    fflush(stdout);
    ssize_t n;
    while ((n = read(fd, buf, sizeof buf)) > 0) {
        ssize_t done = 0;
        while (done < n) {                       /* write() may write less than asked */
            ssize_t w = write(STDOUT_FILENO, buf + done, n - done);
            if (w == -1) {
                if (errno == EINTR) continue;    /* interrupted by a signal: try again */
                perror("write"); close(fd); return 1;
            }
            done += w;
        }
    }
    if (n == -1) { perror("read"); close(fd); return 1; }
    close(fd);
    return 0;
}
