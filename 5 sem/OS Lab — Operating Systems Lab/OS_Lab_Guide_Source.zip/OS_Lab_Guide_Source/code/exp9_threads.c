#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFSIZE 3
#define ITEMS   8

int buffer[BUFSIZE];
int in = 0, out = 0;

sem_t empty;      /* counts free slots,   starts at BUFSIZE */
sem_t full;       /* counts filled slots, starts at 0       */
sem_t mutex;      /* binary semaphore guarding buffer,in,out, starts at 1 */

void *producer(void *arg)
{
    (void)arg;
    for (int i = 1; i <= ITEMS; i++) {
        sem_wait(&empty);                 /* wait for a free slot      */
        sem_wait(&mutex);                 /* enter critical section    */
        buffer[in] = i;
        printf("Produced %d in slot %d\n", i, in);
        in = (in + 1) % BUFSIZE;
        sem_post(&mutex);                 /* leave critical section    */
        sem_post(&full);                  /* one more filled slot      */
    }
    return NULL;
}

void *consumer(void *arg)
{
    (void)arg;
    for (int i = 1; i <= ITEMS; i++) {
        sem_wait(&full);                  /* wait for a filled slot    */
        sem_wait(&mutex);
        int item = buffer[out];
        printf("    Consumed %d from slot %d\n", item, out);
        out = (out + 1) % BUFSIZE;
        sem_post(&mutex);
        sem_post(&empty);                 /* one more free slot        */
        usleep(100000);                   /* slow consumer: 0.1 second */
    }
    return NULL;
}

int main(void)
{
    pthread_t p, c;
    sem_init(&empty, 0, BUFSIZE);
    sem_init(&full, 0, 0);
    sem_init(&mutex, 0, 1);

    pthread_create(&p, NULL, producer, NULL);
    pthread_create(&c, NULL, consumer, NULL);
    pthread_join(p, NULL);
    pthread_join(c, NULL);

    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&mutex);
    return 0;
}
