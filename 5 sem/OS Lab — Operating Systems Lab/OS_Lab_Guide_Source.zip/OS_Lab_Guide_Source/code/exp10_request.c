#include <stdio.h>

/* Safety algorithm: returns 1 and fills seq[] (0-based) if the state is safe */
int is_safe(int p, int r, int alloc[p][r], int need[p][r], int avail[r], int seq[p])
{
    int work[r], finish[p], count = 0, found, i, j;
    for(j=0; j<r; j++)
        work[j] = avail[j];              /* work starts as a copy of avail */
    for(i=0; i<p; i++)
        finish[i] = 0;
    while(count < p){
        found = 0;
        for(i=0; i<p; i++){
            if(finish[i]==0){
                for(j=0; j<r; j++)
                    if(need[i][j] > work[j])
                        break;
                if(j==r){                /* process i can finish */
                    for(j=0; j<r; j++)
                        work[j] += alloc[i][j];
                    seq[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }
        if(found==0)
            return 0;                    /* nobody can finish: unsafe */
    }
    return 1;
}

int main()
{
    int p, r, i, j, q;
    printf("Enter the number of processes:");
    scanf("%d", &p);
    printf("Enter the number of resources:");
    scanf("%d", &r);
    if(p <= 0 || r <= 0)
    {
        printf("Number of processes and resources must be positive\n");
        return 1;
    }
    int max[p][r], alloc[p][r], need[p][r], avail[r], req[r], seq[p];
    printf("Enter the MAX matrix:\n");
    for(i=0; i<p; i++)
        for(j=0; j<r; j++)
            scanf("%d", &max[i][j]);
    printf("Enter the Allocation matrix:\n");
    for(i=0; i<p; i++)
        for(j=0; j<r; j++)
            scanf("%d", &alloc[i][j]);
    printf("Enter the Available matrix:\n");
    for(j=0; j<r; j++)
        scanf("%d", &avail[j]);
    for(i=0; i<p; i++)
        for(j=0; j<r; j++)
            need[i][j] = max[i][j] - alloc[i][j];

    if(!is_safe(p, r, alloc, need, avail, seq))
    {
        printf("System is in unsafe state\n");
        return 0;
    }
    printf("System is in safe state\nSafe Sequence is:");
    for(i=0; i<p; i++)
        printf(" P%d", seq[i]+1);

    printf("\nEnter the process number (1 to %d) that makes a request:", p);
    scanf("%d", &q);
    q--;
    if(q < 0 || q >= p)
    {
        printf("Invalid process number\n");
        return 1;
    }
    printf("Enter its request:\n");
    for(j=0; j<r; j++)
        scanf("%d", &req[j]);

    for(j=0; j<r; j++)                   /* step 1: request <= need ? */
        if(req[j] > need[q][j])
        {
            printf("Error: the process has exceeded its maximum claim\n");
            return 1;
        }
    for(j=0; j<r; j++)                   /* step 2: request <= available ? */
        if(req[j] > avail[j])
        {
            printf("P%d must wait: the resources are not available\n", q+1);
            return 0;
        }
    for(j=0; j<r; j++)                   /* step 3: pretend to grant it */
    {
        avail[j]    -= req[j];
        alloc[q][j] += req[j];
        need[q][j]  -= req[j];
    }
    if(is_safe(p, r, alloc, need, avail, seq))
    {
        printf("Request can be granted. Safe Sequence is:");
        for(i=0; i<p; i++)
            printf(" P%d", seq[i]+1);
        printf("\n");
    }
    else
    {
        for(j=0; j<r; j++)               /* undo the pretend grant */
        {
            avail[j]    += req[j];
            alloc[q][j] -= req[j];
            need[q][j]  += req[j];
        }
        printf("Request cannot be granted: the system would become unsafe\n");
    }
    return 0;
}
