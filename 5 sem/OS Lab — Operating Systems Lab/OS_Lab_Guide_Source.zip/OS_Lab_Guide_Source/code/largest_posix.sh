#!/bin/sh
printf "Enter 3 numbers: "
read a b c
if [ -z "$c" ]; then
    echo "Please enter three numbers"
    exit 1
fi
if [ "$a" -ge "$b" ] && [ "$a" -ge "$c" ]
then
    echo "$a is the greatest"
elif [ "$b" -ge "$a" ] && [ "$b" -ge "$c" ]
then
    echo "$b is the greatest"
else
    echo "$c is the greatest"
fi
