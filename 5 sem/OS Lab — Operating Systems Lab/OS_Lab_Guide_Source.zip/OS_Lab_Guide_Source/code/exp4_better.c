#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(void)
{
    char buf[1024], fname[256];
    printf("Enter the filename to be written: ");
    if (scanf("%255s", fname) != 1) return 1;
    int fd = open(fname, O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (fd == -1) { perror(fname); return 1; }
    printf("Type your text (Ctrl+D to finish):\n");
    ssize_t n;
    while ((n = read(STDIN_FILENO, buf, sizeof buf)) > 0) {
        if (write(fd, buf, n) != n) { perror("write"); close(fd); return 1; }
    }
    if (n == -1) { perror("read"); close(fd); return 1; }
    close(fd);
    printf("Contents written to %s\n", fname);
    return 0;
}
