#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int i, status;
    for (i = 1; i <= 5; i++) {
        fflush(stdout);
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {                      /* child */
            printf("Child %d: pid=%d parent=%d\n", i, getpid(), getppid());
            exit(i);                         /* exit status = child number */
        }
        printf("Parent created child %d with pid %d\n", i, pid);
    }
    while (1) {                              /* reap children until none are left */
        pid_t done = wait(&status);
        if (done == -1) break;               /* ECHILD: no more children */
        if (WIFEXITED(status))
            printf("Parent: child %d ended with status %d\n", done, WEXITSTATUS(status));
    }
    printf("Parent %d: all children finished\n", getpid());
    return 0;
}
