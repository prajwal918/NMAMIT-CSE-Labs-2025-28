#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    char sname[100];
    int status;
    printf("Enter shell script name: ");
    if (scanf("%99s", sname) != 1) return 1;
    if (access(sname, R_OK) == -1) {
        perror("Error: cannot open script");
        return 1;
    }
    pid_t pid = fork();
    if (pid == 0) {                              /* child: becomes the shell */
        execl("/bin/sh", "sh", sname, (char *)NULL);
        perror("Error: cannot execute script");  /* only if exec failed */
        _exit(127);
    }
    waitpid(pid, &status, 0);                    /* parent: wait for child */
    if (WIFEXITED(status))
        printf("Parent: script finished, exit status %d\n", WEXITSTATUS(status));
    return 0;
}
