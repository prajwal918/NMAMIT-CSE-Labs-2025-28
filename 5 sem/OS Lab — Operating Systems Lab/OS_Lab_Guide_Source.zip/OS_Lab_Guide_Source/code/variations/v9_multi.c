#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFSIZE 3
#define PER_THREAD 4      /* each producer makes 4 items, each consumer takes 4 */

int buffer[BUFSIZE];
int in = 0, out = 0;
sem_t empty, full, mutex;

void *producer(void *arg)
{
    int id = *(int *)arg;
    for (int i = 1; i <= PER_THREAD; i++) {
        int item = id * 100 + i;
        sem_wait(&empty);
        sem_wait(&mutex);
        buffer[in] = item;
        printf("Producer %d put %d in slot %d\n", id, item, in);
        in = (in + 1) % BUFSIZE;
        sem_post(&mutex);
        sem_post(&full);
    }
    return NULL;
}

void *consumer(void *arg)
{
    int id = *(int *)arg;
    for (int i = 1; i <= PER_THREAD; i++) {
        sem_wait(&full);
        sem_wait(&mutex);
        int item = buffer[out];
        printf("    Consumer %d took %d from slot %d\n", id, item, out);
        out = (out + 1) % BUFSIZE;
        sem_post(&mutex);
        sem_post(&empty);
        usleep(50000);
    }
    return NULL;
}

int main(void)
{
    pthread_t p[2], c[2];
    int id[2] = {1, 2};
    sem_init(&empty, 0, BUFSIZE);
    sem_init(&full, 0, 0);
    sem_init(&mutex, 0, 1);
    for (int k = 0; k < 2; k++) {
        pthread_create(&p[k], NULL, producer, &id[k]);
        pthread_create(&c[k], NULL, consumer, &id[k]);
    }
    for (int k = 0; k < 2; k++) {
        pthread_join(p[k], NULL);
        pthread_join(c[k], NULL);
    }
    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&mutex);
    return 0;
}
