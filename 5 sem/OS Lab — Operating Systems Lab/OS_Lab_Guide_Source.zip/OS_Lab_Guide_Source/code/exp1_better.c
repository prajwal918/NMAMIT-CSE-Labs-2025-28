#include <stdio.h>
#include <unistd.h>

int main(void)
{
    char sname[100];
    printf("Enter shell script name: ");
    if (scanf("%99s", sname) != 1) {        /* did scanf really read a word? */
        fprintf(stderr, "Error: no script name given\n");
        return 1;
    }
    if (access(sname, R_OK) == -1) {        /* exists and readable? */
        perror("Error: cannot open script");
        return 1;
    }
    execl("/bin/sh", "sh", sname, (char *)NULL);
    /* we reach this line ONLY if execl() failed */
    perror("Error: cannot execute script");
    return 1;
}
