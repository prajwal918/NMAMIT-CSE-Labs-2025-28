#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

static volatile sig_atomic_t stop = 0;       /* handler sets it, main() reads it */

/* write() is async-signal-safe, printf() is not */
#define SAY(msg) do { ssize_t r_ = write(STDOUT_FILENO, msg, sizeof(msg) - 1); (void)r_; } while (0)

static void handler(int sig)
{
    switch (sig) {
    case SIGINT:  SAY("Caught an Interrupt Signal\n"); break;
    case SIGHUP:  SAY("Caught a Hangup Signal\n");     break;
    case SIGUSR1: SAY("Caught a User Signal\n");       break;
    case SIGALRM: SAY("Caught an Alarm Signal\n");     break;
    case SIGTERM: SAY("Caught a Terminate Signal\n");  stop = 1; break;
    }
}

int main(void)
{
    int sigs[] = { SIGINT, SIGTERM, SIGHUP, SIGALRM, SIGUSR1 };
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);                /* block no extra signals in handler */
    for (int i = 0; i < 5; i++)
        sigaction(sigs[i], &sa, NULL);

    alarm(20);
    printf("Process Id of program running = %d\n", getpid());
    while (!stop) {
        printf("Waiting for signal\n");
        sleep(5);
    }
    printf("Exiting cleanly\n");
    return 0;
}
