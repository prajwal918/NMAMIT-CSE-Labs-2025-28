#include <stdio.h>

struct Process { int pid, at, bt, rem, ct, tat, wt; };

int main(void)
{
    int n, i, j, tq, time = 0, next = 0, finished = 0;
    int head = 0, tail = 0, count = 0;           /* circular ready queue */
    double twt = 0, ttat = 0;
    printf("Enter number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0) return 1;
    struct Process p[n], temp;
    int q[n];                                    /* holds indexes of waiting processes */
    for (i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Arrival time and burst time of P%d: ", i + 1);
        if (scanf("%d %d", &p[i].at, &p[i].bt) != 2) return 1;
        p[i].rem = p[i].bt;
    }
    printf("Enter the time quantum: ");
    if (scanf("%d", &tq) != 1 || tq <= 0) return 1;
    for (i = 0; i < n - 1; i++)                  /* sort by arrival time */
        for (j = 0; j < n - 1 - i; j++)
            if (p[j].at > p[j + 1].at) {
                temp = p[j]; p[j] = p[j + 1]; p[j + 1] = temp;
            }
    while (finished < n) {
        while (next < n && p[next].at <= time) { /* admit everyone who has arrived */
            q[tail] = next++;  tail = (tail + 1) % n;  count++;
        }
        if (count == 0) { time = p[next].at; continue; }   /* CPU idle: jump ahead */
        i = q[head];  head = (head + 1) % n;  count--;     /* take the front process */
        int slice = (p[i].rem < tq) ? p[i].rem : tq;
        time += slice;
        p[i].rem -= slice;
        while (next < n && p[next].at <= time) { /* arrivals during the slice go FIRST */
            q[tail] = next++;  tail = (tail + 1) % n;  count++;
        }
        if (p[i].rem > 0) {                      /* not finished: back of the queue */
            q[tail] = i;  tail = (tail + 1) % n;  count++;
        } else {                                 /* finished */
            p[i].ct  = time;
            p[i].tat = p[i].ct - p[i].at;
            p[i].wt  = p[i].tat - p[i].bt;
            finished++;
            twt += p[i].wt;  ttat += p[i].tat;
        }
    }
    printf("\nPID AT BT CT TAT WT\n");
    for (i = 0; i < n; i++)
        printf("P%d %d %d %d %d %d\n", p[i].pid, p[i].at, p[i].bt,
               p[i].ct, p[i].tat, p[i].wt);
    printf("Average WT = %.2f   Average TAT = %.2f\n", twt / n, ttat / n);
    return 0;
}
