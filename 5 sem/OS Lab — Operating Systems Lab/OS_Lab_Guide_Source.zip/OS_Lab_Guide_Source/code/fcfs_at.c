#include <stdio.h>

struct Process { int pid, at, bt, ct, tat, wt; };

int main(void)
{
    int n, i, j, time = 0;
    double twt = 0, ttat = 0;
    printf("Enter number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0) return 1;
    struct Process p[n], temp;
    for (i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Arrival time and burst time of P%d: ", i + 1);
        if (scanf("%d %d", &p[i].at, &p[i].bt) != 2) return 1;
    }
    for (i = 0; i < n - 1; i++)                 /* bubble sort by arrival time */
        for (j = 0; j < n - 1 - i; j++)         /* (equal times keep pid order) */
            if (p[j].at > p[j + 1].at) {
                temp = p[j]; p[j] = p[j + 1]; p[j + 1] = temp;
            }
    for (i = 0; i < n; i++) {
        if (time < p[i].at) time = p[i].at;     /* CPU idle until it arrives */
        time += p[i].bt;                        /* run the whole burst       */
        p[i].ct  = time;                        /* completion time           */
        p[i].tat = p[i].ct - p[i].at;           /* turnaround = CT - AT      */
        p[i].wt  = p[i].tat - p[i].bt;          /* waiting    = TAT - BT     */
        twt += p[i].wt;  ttat += p[i].tat;
    }
    printf("\nPID AT BT CT TAT WT\n");
    for (i = 0; i < n; i++)
        printf("P%d %d %d %d %d %d\n", p[i].pid, p[i].at, p[i].bt,
               p[i].ct, p[i].tat, p[i].wt);
    printf("Average WT = %.2f   Average TAT = %.2f\n", twt / n, ttat / n);
    return 0;
}
