#include <stdio.h>
#include <semaphore.h>

int main(void)
{
    int size, choice = 0, in = 0, out = 0, value;
    sem_t empty, full;                        /* two counting semaphores */

    printf("Enter the buffer size: ");
    if (scanf("%d", &size) != 1 || size <= 0) {
        printf("Buffer size must be a positive number\n");
        return 1;
    }
    int buffer[size];
    sem_init(&empty, 0, size);                /* every slot is empty at the start */
    sem_init(&full, 0, 0);                    /* no slot is filled at the start   */

    do {
        printf("\n1. Produce\n2. Consume\n3. Exit\nEnter the choice: ");
        if (scanf("%d", &choice) != 1) break;
        switch (choice) {
        case 1:
            if (sem_trywait(&empty) == -1) {          /* no free slot: would block */
                printf("Buffer is full\n");
            } else {
                printf("Enter the value: ");
                if (scanf("%d", &value) != 1) value = 0;
                buffer[in] = value;
                in = (in + 1) % size;
                sem_post(&full);                      /* one more filled slot */
            }
            break;
        case 2:
            if (sem_trywait(&full) == -1) {           /* nothing to take: would block */
                printf("Buffer is empty\n");
            } else {
                value = buffer[out];
                out = (out + 1) % size;
                printf("Consumed item is: %d\n", value);
                sem_post(&empty);                     /* one more free slot */
            }
            break;
        case 3:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice\n");
        }
    } while (choice != 3);

    sem_destroy(&empty);
    sem_destroy(&full);
    return 0;
}
